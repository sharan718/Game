import { View, Text, StyleSheet, TouchableOpacity, ImageBackground } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Play, Trophy, Users, Star } from 'lucide-react-native';
import { useRouter } from 'expo-router';
import { useGameStore } from '@/store/gameStore';

export default function HomeScreen() {
  const router = useRouter();
  const { highScore, coins, totalGames } = useGameStore();

  const handlePlayGame = () => {
    router.push('/game');
  };

  return (
    <LinearGradient
      colors={['#1E293B', '#334155', '#475569']}
      style={styles.container}
    >
      <View style={styles.header}>
        <Text style={styles.title}>SUBWAY</Text>
        <Text style={styles.subtitle}>SURFERS</Text>
      </View>

      <View style={styles.statsContainer}>
        <View style={styles.statCard}>
          <Trophy size={24} color="#F59E0B" />
          <Text style={styles.statLabel}>High Score</Text>
          <Text style={styles.statValue}>{highScore.toLocaleString()}</Text>
        </View>
        
        <View style={styles.statCard}>
          <Star size={24} color="#F59E0B" />
          <Text style={styles.statLabel}>Coins</Text>
          <Text style={styles.statValue}>{coins.toLocaleString()}</Text>
        </View>
        
        <View style={styles.statCard}>
          <Users size={24} color="#F59E0B" />
          <Text style={styles.statLabel}>Games</Text>
          <Text style={styles.statValue}>{totalGames}</Text>
        </View>
      </View>

      <TouchableOpacity style={styles.playButton} onPress={handlePlayGame}>
        <LinearGradient
          colors={['#F59E0B', '#D97706']}
          style={styles.playButtonGradient}
        >
          <Play size={32} color="#FFFFFF" style={styles.playIcon} />
          <Text style={styles.playButtonText}>PLAY NOW</Text>
        </LinearGradient>
      </TouchableOpacity>

      <View style={styles.featuresContainer}>
        <Text style={styles.featuresTitle}>Game Features</Text>
        <View style={styles.featuresList}>
          <Text style={styles.featureItem}>🏃‍♂️ Endless Running Action</Text>
          <Text style={styles.featureItem}>🪙 Collect Coins & Power-ups</Text>
          <Text style={styles.featureItem}>🚀 Jetpack & Special Abilities</Text>
          <Text style={styles.featureItem}>🏆 Compete for High Scores</Text>
        </View>
      </View>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 20,
    paddingTop: 60,
  },
  header: {
    alignItems: 'center',
    marginBottom: 40,
  },
  title: {
    fontSize: 48,
    fontFamily: 'Inter-Bold',
    color: '#F59E0B',
    letterSpacing: 4,
    textShadowColor: '#000000',
    textShadowOffset: { width: 2, height: 2 },
    textShadowRadius: 4,
  },
  subtitle: {
    fontSize: 24,
    fontFamily: 'Inter-SemiBold',
    color: '#E2E8F0',
    letterSpacing: 2,
    marginTop: -8,
  },
  statsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 40,
  },
  statCard: {
    backgroundColor: '#2D3748',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    flex: 1,
    marginHorizontal: 4,
    borderWidth: 1,
    borderColor: '#4A5568',
  },
  statLabel: {
    fontSize: 12,
    fontFamily: 'Inter-SemiBold',
    color: '#A0AEC0',
    marginTop: 8,
  },
  statValue: {
    fontSize: 18,
    fontFamily: 'Inter-Bold',
    color: '#F7FAFC',
    marginTop: 4,
  },
  playButton: {
    marginBottom: 40,
    borderRadius: 20,
    overflow: 'hidden',
    elevation: 8,
    shadowColor: '#F59E0B',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
  },
  playButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 20,
    paddingHorizontal: 32,
  },
  playIcon: {
    marginRight: 12,
  },
  playButtonText: {
    fontSize: 24,
    fontFamily: 'Inter-Bold',
    color: '#FFFFFF',
    letterSpacing: 2,
  },
  featuresContainer: {
    backgroundColor: '#2D3748',
    padding: 20,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: '#4A5568',
  },
  featuresTitle: {
    fontSize: 20,
    fontFamily: 'Inter-Bold',
    color: '#F7FAFC',
    marginBottom: 16,
    textAlign: 'center',
  },
  featuresList: {
    gap: 12,
  },
  featureItem: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#E2E8F0',
    textAlign: 'center',
  },
});