import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Switch } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Settings, Volume2, VolumeX, Smartphone, Trophy, RotateCcw } from 'lucide-react-native';
import { useState } from 'react';
import { useGameStore } from '@/store/gameStore';

export default function SettingsScreen() {
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [musicEnabled, setMusicEnabled] = useState(true);
  const [hapticEnabled, setHapticEnabled] = useState(true);
  
  const { resetProgress, highScore, totalGames, coins } = useGameStore();

  const handleResetProgress = () => {
    resetProgress();
  };

  const settingsItems = [
    {
      id: 'sound',
      title: 'Sound Effects',
      subtitle: 'Enable game sound effects',
      value: soundEnabled,
      onValueChange: setSoundEnabled,
      icon: soundEnabled ? <Volume2 size={24} color="#10B981" /> : <VolumeX size={24} color="#EF4444" />,
    },
    {
      id: 'music',
      title: 'Background Music',
      subtitle: 'Enable background music',
      value: musicEnabled,
      onValueChange: setMusicEnabled,
      icon: musicEnabled ? <Volume2 size={24} color="#10B981" /> : <VolumeX size={24} color="#EF4444" />,
    },
    {
      id: 'haptic',
      title: 'Haptic Feedback',
      subtitle: 'Enable vibration feedback',
      value: hapticEnabled,
      onValueChange: setHapticEnabled,
      icon: <Smartphone size={24} color={hapticEnabled ? "#10B981" : "#EF4444"} />,
    },
  ];

  return (
    <LinearGradient
      colors={['#1E293B', '#334155', '#475569']}
      style={styles.container}
    >
      <View style={styles.header}>
        <Settings size={32} color="#F59E0B" />
        <Text style={styles.title}>SETTINGS</Text>
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {/* Game Settings */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Game Settings</Text>
          {settingsItems.map((item) => (
            <View key={item.id} style={styles.settingItem}>
              <View style={styles.settingIcon}>
                {item.icon}
              </View>
              <View style={styles.settingContent}>
                <Text style={styles.settingTitle}>{item.title}</Text>
                <Text style={styles.settingSubtitle}>{item.subtitle}</Text>
              </View>
              <Switch
                value={item.value}
                onValueChange={item.onValueChange}
                trackColor={{ false: '#374151', true: '#F59E0B' }}
                thumbColor={item.value ? '#FFFFFF' : '#9CA3AF'}
              />
            </View>
          ))}
        </View>

        {/* Statistics */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Statistics</Text>
          <View style={styles.statsContainer}>
            <View style={styles.statItem}>
              <Trophy size={20} color="#F59E0B" />
              <Text style={styles.statValue}>{highScore.toLocaleString()}</Text>
              <Text style={styles.statLabel}>High Score</Text>
            </View>
            <View style={styles.statItem}>
              <Text style={styles.statValue}>{totalGames}</Text>
              <Text style={styles.statLabel}>Games Played</Text>
            </View>
            <View style={styles.statItem}>
              <Text style={styles.statValue}>{coins.toLocaleString()}</Text>
              <Text style={styles.statLabel}>Total Coins</Text>
            </View>
          </View>
        </View>

        {/* Actions */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Actions</Text>
          <TouchableOpacity
            style={styles.actionButton}
            onPress={handleResetProgress}
          >
            <RotateCcw size={24} color="#EF4444" />
            <View style={styles.actionContent}>
              <Text style={styles.actionTitle}>Reset Progress</Text>
              <Text style={styles.actionSubtitle}>Clear all game data and start fresh</Text>
            </View>
          </TouchableOpacity>
        </View>

        {/* About */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>About</Text>
          <View style={styles.aboutContainer}>
            <Text style={styles.aboutTitle}>Subway Surfers Clone</Text>
            <Text style={styles.aboutVersion}>Version 1.0.0</Text>
            <Text style={styles.aboutDescription}>
              A faithful recreation of the classic endless runner game.
              Swipe to move, collect coins, and avoid obstacles!
            </Text>
          </View>
        </View>
      </ScrollView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: 60,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    marginBottom: 20,
  },
  title: {
    fontSize: 24,
    fontFamily: 'Inter-Bold',
    color: '#F7FAFC',
    marginLeft: 12,
    letterSpacing: 2,
  },
  content: {
    flex: 1,
    paddingHorizontal: 20,
  },
  section: {
    marginBottom: 30,
  },
  sectionTitle: {
    fontSize: 18,
    fontFamily: 'Inter-Bold',
    color: '#F7FAFC',
    marginBottom: 16,
  },
  settingItem: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#2D3748',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#4A5568',
  },
  settingIcon: {
    marginRight: 12,
  },
  settingContent: {
    flex: 1,
  },
  settingTitle: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#F7FAFC',
    marginBottom: 4,
  },
  settingSubtitle: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#A0AEC0',
  },
  statsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    backgroundColor: '#2D3748',
    borderRadius: 12,
    padding: 16,
    borderWidth: 1,
    borderColor: '#4A5568',
  },
  statItem: {
    alignItems: 'center',
    flex: 1,
  },
  statValue: {
    fontSize: 20,
    fontFamily: 'Inter-Bold',
    color: '#F7FAFC',
    marginTop: 8,
  },
  statLabel: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#A0AEC0',
    marginTop: 4,
    textAlign: 'center',
  },
  actionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#2D3748',
    borderRadius: 12,
    padding: 16,
    borderWidth: 1,
    borderColor: '#EF4444',
  },
  actionContent: {
    marginLeft: 12,
    flex: 1,
  },
  actionTitle: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#EF4444',
    marginBottom: 4,
  },
  actionSubtitle: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#A0AEC0',
  },
  aboutContainer: {
    backgroundColor: '#2D3748',
    borderRadius: 12,
    padding: 16,
    borderWidth: 1,
    borderColor: '#4A5568',
  },
  aboutTitle: {
    fontSize: 18,
    fontFamily: 'Inter-Bold',
    color: '#F7FAFC',
    marginBottom: 4,
  },
  aboutVersion: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#F59E0B',
    marginBottom: 12,
  },
  aboutDescription: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#A0AEC0',
    lineHeight: 20,
  },
});