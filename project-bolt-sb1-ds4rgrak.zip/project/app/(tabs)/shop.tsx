import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { ShoppingBag, Star, Zap, Shield, Magnet } from 'lucide-react-native';
import { useGameStore } from '@/store/gameStore';

interface ShopItem {
  id: string;
  name: string;
  description: string;
  price: number;
  type: 'character' | 'powerup' | 'upgrade';
  icon: React.ReactNode;
  owned: boolean;
}

export default function ShopScreen() {
  const { coins, purchaseItem, ownedItems } = useGameStore();

  const shopItems: ShopItem[] = [
    {
      id: 'character_jake',
      name: 'Jake',
      description: 'The original subway surfer',
      price: 0,
      type: 'character',
      icon: <Star size={24} color="#F59E0B" />,
      owned: ownedItems.includes('character_jake'),
    },
    {
      id: 'character_tricky',
      name: 'Tricky',
      description: 'The rebellious artist',
      price: 5000,
      type: 'character',
      icon: <Star size={24} color="#F59E0B" />,
      owned: ownedItems.includes('character_tricky'),
    },
    {
      id: 'powerup_jetpack',
      name: 'Jetpack Upgrade',
      description: 'Longer jetpack duration',
      price: 2000,
      type: 'powerup',
      icon: <Zap size={24} color="#10B981" />,
      owned: ownedItems.includes('powerup_jetpack'),
    },
    {
      id: 'powerup_magnet',
      name: 'Super Magnet',
      description: 'Stronger coin magnet',
      price: 1500,
      type: 'powerup',
      icon: <Magnet size={24} color="#8B5CF6" />,
      owned: ownedItems.includes('powerup_magnet'),
    },
    {
      id: 'upgrade_multiplier',
      name: '2x Score Multiplier',
      description: 'Double your score',
      price: 10000,
      type: 'upgrade',
      icon: <Shield size={24} color="#EF4444" />,
      owned: ownedItems.includes('upgrade_multiplier'),
    },
  ];

  const handlePurchase = (item: ShopItem) => {
    if (item.owned) {
      Alert.alert('Already Owned', 'You already own this item!');
      return;
    }

    if (coins < item.price) {
      Alert.alert('Not Enough Coins', `You need ${item.price - coins} more coins to purchase this item.`);
      return;
    }

    Alert.alert(
      'Confirm Purchase',
      `Are you sure you want to buy ${item.name} for ${item.price} coins?`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Buy',
          onPress: () => {
            purchaseItem(item.id, item.price);
            Alert.alert('Purchase Successful', `You now own ${item.name}!`);
          },
        },
      ]
    );
  };

  const renderShopItem = (item: ShopItem) => (
    <TouchableOpacity
      key={item.id}
      style={[styles.shopItem, item.owned && styles.ownedItem]}
      onPress={() => handlePurchase(item)}
    >
      <View style={styles.itemHeader}>
        {item.icon}
        <View style={styles.itemInfo}>
          <Text style={styles.itemName}>{item.name}</Text>
          <Text style={styles.itemDescription}>{item.description}</Text>
        </View>
      </View>
      
      <View style={styles.itemFooter}>
        {item.owned ? (
          <Text style={styles.ownedText}>OWNED</Text>
        ) : (
          <TouchableOpacity
            style={styles.buyButton}
            onPress={() => handlePurchase(item)}
          >
            <Text style={styles.buyButtonText}>{item.price} 🪙</Text>
          </TouchableOpacity>
        )}
      </View>
    </TouchableOpacity>
  );

  return (
    <LinearGradient
      colors={['#1E293B', '#334155', '#475569']}
      style={styles.container}
    >
      <View style={styles.header}>
        <ShoppingBag size={32} color="#F59E0B" />
        <Text style={styles.title}>SHOP</Text>
        <View style={styles.coinsDisplay}>
          <Text style={styles.coinsText}>{coins.toLocaleString()} 🪙</Text>
        </View>
      </View>

      <ScrollView style={styles.shopContainer} showsVerticalScrollIndicator={false}>
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Characters</Text>
          {shopItems
            .filter(item => item.type === 'character')
            .map(renderShopItem)}
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Power-ups</Text>
          {shopItems
            .filter(item => item.type === 'powerup')
            .map(renderShopItem)}
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Upgrades</Text>
          {shopItems
            .filter(item => item.type === 'upgrade')
            .map(renderShopItem)}
        </View>
      </ScrollView>

      <View style={styles.footer}>
        <Text style={styles.footerText}>
          Earn coins by playing the game and collecting them during runs!
        </Text>
      </View>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: 60,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    marginBottom: 20,
  },
  title: {
    fontSize: 24,
    fontFamily: 'Inter-Bold',
    color: '#F7FAFC',
    letterSpacing: 2,
  },
  coinsDisplay: {
    backgroundColor: '#2D3748',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: '#4A5568',
  },
  coinsText: {
    fontSize: 16,
    fontFamily: 'Inter-Bold',
    color: '#F59E0B',
  },
  shopContainer: {
    flex: 1,
    paddingHorizontal: 20,
  },
  section: {
    marginBottom: 30,
  },
  sectionTitle: {
    fontSize: 20,
    fontFamily: 'Inter-Bold',
    color: '#F7FAFC',
    marginBottom: 16,
  },
  shopItem: {
    backgroundColor: '#2D3748',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#4A5568',
  },
  ownedItem: {
    borderColor: '#10B981',
    backgroundColor: '#064E3B',
  },
  itemHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  itemInfo: {
    marginLeft: 12,
    flex: 1,
  },
  itemName: {
    fontSize: 18,
    fontFamily: 'Inter-Bold',
    color: '#F7FAFC',
    marginBottom: 4,
  },
  itemDescription: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#A0AEC0',
  },
  itemFooter: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    alignItems: 'center',
  },
  buyButton: {
    backgroundColor: '#F59E0B',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
  },
  buyButtonText: {
    fontSize: 14,
    fontFamily: 'Inter-Bold',
    color: '#FFFFFF',
  },
  ownedText: {
    fontSize: 14,
    fontFamily: 'Inter-Bold',
    color: '#10B981',
  },
  footer: {
    padding: 20,
    backgroundColor: '#1A202C',
    borderTopWidth: 1,
    borderTopColor: '#2D3748',
  },
  footerText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#A0AEC0',
    textAlign: 'center',
  },
});