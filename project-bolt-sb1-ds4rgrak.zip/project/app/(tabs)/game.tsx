import { View, Text, StyleSheet, Dimensions, Alert } from 'react-native';
import { useEffect, useRef, useState } from 'react';
import { GestureDetector, Gesture } from 'react-native-gesture-handler';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withTiming,
  runOnJS,
  useAnimatedGestureHandler,
  withSpring,
} from 'react-native-reanimated';
import { LinearGradient } from 'expo-linear-gradient';
import { GameHUD } from '@/components/game/GameHUD';
import { Player } from '@/components/game/Player';
import { Obstacle } from '@/components/game/Obstacle';
import { Coin } from '@/components/game/Coin';
import { PowerUp } from '@/components/game/PowerUp';
import { useGameLogic } from '@/hooks/useGameLogic';
import { useGameStore } from '@/store/gameStore';

const { width: SCREEN_WIDTH, height: SCREEN_HEIGHT } = Dimensions.get('window');

export default function GameScreen() {
  const {
    gameState,
    playerPosition,
    score,
    coins,
    isGameRunning,
    obstacles,
    coinItems,
    powerUps,
    activePowerUps,
    gameSpeed,
    startGame,
    pauseGame,
    gameOver,
    movePlayer,
    jumpPlayer,
    slidePlayer,
  } = useGameLogic();

  const panGesture = Gesture.Pan()
    .onUpdate((event) => {
      if (!isGameRunning) return;
      
      const deltaX = event.translationX;
      const deltaY = event.translationY;
      
      // Swipe sensitivity
      const threshold = 30;
      
      if (Math.abs(deltaX) > Math.abs(deltaY)) {
        // Horizontal swipe
        if (deltaX > threshold) {
          runOnJS(movePlayer)('right');
        } else if (deltaX < -threshold) {
          runOnJS(movePlayer)('left');
        }
      } else {
        // Vertical swipe
        if (deltaY < -threshold) {
          runOnJS(jumpPlayer)();
        } else if (deltaY > threshold) {
          runOnJS(slidePlayer)();
        }
      }
    });

  const tapGesture = Gesture.Tap()
    .onEnd(() => {
      if (gameState === 'waiting') {
        runOnJS(startGame)();
      } else if (gameState === 'gameOver') {
        runOnJS(startGame)();
      }
    });

  const combinedGesture = Gesture.Race(panGesture, tapGesture);

  return (
    <View style={styles.container}>
      <LinearGradient
        colors={['#0F172A', '#1E293B', '#334155']}
        style={styles.background}
      >
        <GestureDetector gesture={combinedGesture}>
          <View style={styles.gameArea}>
            {/* Track Lines */}
            <View style={styles.trackContainer}>
              <View style={[styles.trackLine, { left: SCREEN_WIDTH / 3 }]} />
              <View style={[styles.trackLine, { left: (SCREEN_WIDTH * 2) / 3 }]} />
            </View>

            {/* Game Objects */}
            <Player
              position={playerPosition}
              isRunning={isGameRunning}
              activePowerUps={activePowerUps}
            />

            {obstacles.map((obstacle) => (
              <Obstacle
                key={obstacle.id}
                obstacle={obstacle}
                gameSpeed={gameSpeed}
              />
            ))}

            {coinItems.map((coin) => (
              <Coin
                key={coin.id}
                coin={coin}
                gameSpeed={gameSpeed}
              />
            ))}

            {powerUps.map((powerUp) => (
              <PowerUp
                key={powerUp.id}
                powerUp={powerUp}
                gameSpeed={gameSpeed}
              />
            ))}

            {/* Game State Overlays */}
            {gameState === 'waiting' && (
              <View style={styles.startOverlay}>
                <Text style={styles.startTitle}>SUBWAY SURFERS</Text>
                <Text style={styles.startSubtitle}>Tap to Start</Text>
                <Text style={styles.instructions}>
                  Swipe left/right to change lanes{'\n'}
                  Swipe up to jump{'\n'}
                  Swipe down to slide
                </Text>
              </View>
            )}

            {gameState === 'gameOver' && (
              <View style={styles.gameOverOverlay}>
                <Text style={styles.gameOverTitle}>GAME OVER</Text>
                <Text style={styles.finalScore}>Score: {score.toLocaleString()}</Text>
                <Text style={styles.coinsCollected}>Coins: {coins}</Text>
                <Text style={styles.restartText}>Tap to Restart</Text>
              </View>
            )}
          </View>
        </GestureDetector>

        <GameHUD
          score={score}
          coins={coins}
          isGameRunning={isGameRunning}
          activePowerUps={activePowerUps}
          onPause={pauseGame}
          gameState={gameState}
        />
      </LinearGradient>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  background: {
    flex: 1,
  },
  gameArea: {
    flex: 1,
    position: 'relative',
  },
  trackContainer: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
  },
  trackLine: {
    position: 'absolute',
    top: 0,
    bottom: 0,
    width: 2,
    backgroundColor: '#475569',
    opacity: 0.6,
  },
  startOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.8)',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 1000,
  },
  startTitle: {
    fontSize: 36,
    fontFamily: 'Inter-Bold',
    color: '#F59E0B',
    marginBottom: 16,
    textAlign: 'center',
    letterSpacing: 2,
  },
  startSubtitle: {
    fontSize: 24,
    fontFamily: 'Inter-SemiBold',
    color: '#E2E8F0',
    marginBottom: 32,
    textAlign: 'center',
  },
  instructions: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#94A3B8',
    textAlign: 'center',
    lineHeight: 24,
  },
  gameOverOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.9)',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 1000,
  },
  gameOverTitle: {
    fontSize: 42,
    fontFamily: 'Inter-Bold',
    color: '#EF4444',
    marginBottom: 24,
    textAlign: 'center',
    letterSpacing: 2,
  },
  finalScore: {
    fontSize: 24,
    fontFamily: 'Inter-Bold',
    color: '#F59E0B',
    marginBottom: 12,
    textAlign: 'center',
  },
  coinsCollected: {
    fontSize: 20,
    fontFamily: 'Inter-SemiBold',
    color: '#10B981',
    marginBottom: 32,
    textAlign: 'center',
  },
  restartText: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: '#94A3B8',
    textAlign: 'center',
  },
});