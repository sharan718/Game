import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { Pause, Play } from 'lucide-react-native';
import { ActivePowerUp } from '@/hooks/useGameLogic';

interface GameHUDProps {
  score: number;
  coins: number;
  isGameRunning: boolean;
  activePowerUps: ActivePowerUp[];
  onPause: () => void;
  gameState: string;
}

export function GameHUD({ score, coins, isGameRunning, activePowerUps, onPause, gameState }: GameHUDProps) {
  if (gameState === 'waiting' || gameState === 'gameOver') {
    return null;
  }

  return (
    <View style={styles.container}>
      <View style={styles.statsContainer}>
        <View style={styles.statItem}>
          <Text style={styles.statLabel}>SCORE</Text>
          <Text style={styles.statValue}>{score.toLocaleString()}</Text>
        </View>
        
        <View style={styles.statItem}>
          <Text style={styles.statLabel}>COINS</Text>
          <Text style={styles.statValue}>{coins} 🪙</Text>
        </View>
      </View>

      <TouchableOpacity style={styles.pauseButton} onPress={onPause}>
        {isGameRunning ? (
          <Pause size={24} color="#FFFFFF" />
        ) : (
          <Play size={24} color="#FFFFFF" />
        )}
      </TouchableOpacity>

      {activePowerUps.length > 0 && (
        <View style={styles.powerUpsContainer}>
          {activePowerUps.map((powerUp, index) => (
            <View key={index} style={styles.powerUpItem}>
              <Text style={styles.powerUpText}>
                {getPowerUpEmoji(powerUp.type)}
              </Text>
              <View style={styles.powerUpBar}>
                <View 
                  style={[
                    styles.powerUpProgress,
                    {
                      width: `${(powerUp.duration / powerUp.maxDuration) * 100}%`,
                      backgroundColor: getPowerUpColor(powerUp.type),
                    }
                  ]}
                />
              </View>
            </View>
          ))}
        </View>
      )}
    </View>
  );
}

const getPowerUpEmoji = (type: string) => {
  switch (type) {
    case 'jetpack': return '🚀';
    case 'magnet': return '🧲';
    case 'multiplier': return '✨';
    case 'speed': return '⚡';
    default: return '🎯';
  }
};

const getPowerUpColor = (type: string) => {
  switch (type) {
    case 'jetpack': return '#10B981';
    case 'magnet': return '#8B5CF6';
    case 'multiplier': return '#F59E0B';
    case 'speed': return '#EF4444';
    default: return '#6B7280';
  }
};

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    paddingTop: 60,
    paddingHorizontal: 20,
    zIndex: 100,
  },
  statsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  statItem: {
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    minWidth: 100,
    alignItems: 'center',
  },
  statLabel: {
    fontSize: 12,
    fontFamily: 'Inter-SemiBold',
    color: '#A0AEC0',
    marginBottom: 2,
  },
  statValue: {
    fontSize: 18,
    fontFamily: 'Inter-Bold',
    color: '#F7FAFC',
  },
  pauseButton: {
    position: 'absolute',
    top: 70,
    right: 20,
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    padding: 12,
    borderRadius: 25,
    width: 50,
    height: 50,
    alignItems: 'center',
    justifyContent: 'center',
  },
  powerUpsContainer: {
    position: 'absolute',
    top: 140,
    left: 20,
    right: 20,
  },
  powerUpItem: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 12,
    marginBottom: 8,
  },
  powerUpText: {
    fontSize: 18,
    marginRight: 12,
  },
  powerUpBar: {
    flex: 1,
    height: 6,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    borderRadius: 3,
    overflow: 'hidden',
  },
  powerUpProgress: {
    height: '100%',
    borderRadius: 3,
  },
});