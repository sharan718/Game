import { View, StyleSheet } from 'react-native';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withSpring,
  withTiming,
  interpolate,
} from 'react-native-reanimated';
import { useEffect } from 'react';
import { Position, ActivePowerUp } from '@/hooks/useGameLogic';

interface PlayerProps {
  position: Position;
  isRunning: boolean;
  activePowerUps: ActivePowerUp[];
}

export function Player({ position, isRunning, activePowerUps }: PlayerProps) {
  const translateX = useSharedValue(position.x);
  const translateY = useSharedValue(position.y);
  const scale = useSharedValue(1);
  const rotation = useSharedValue(0);

  const hasJetpack = activePowerUps.some(p => p.type === 'jetpack');
  const hasSpeed = activePowerUps.some(p => p.type === 'speed');

  useEffect(() => {
    translateX.value = withSpring(position.x, {
      damping: 20,
      stiffness: 200,
    });
  }, [position.x]);

  useEffect(() => {
    if (position.action === 'jumping') {
      translateY.value = withTiming(position.y - 100, { duration: 250 }, () => {
        translateY.value = withTiming(position.y, { duration: 250 });
      });
      scale.value = withTiming(1.2, { duration: 250 }, () => {
        scale.value = withTiming(1, { duration: 250 });
      });
    } else if (position.action === 'sliding') {
      scale.value = withTiming(0.8, { duration: 250 }, () => {
        scale.value = withTiming(1, { duration: 250 });
      });
    }
  }, [position.action]);

  useEffect(() => {
    if (isRunning) {
      rotation.value = withTiming(360, { duration: 1000 }, () => {
        rotation.value = 0;
      });
    }
  }, [isRunning]);

  const animatedStyle = useAnimatedStyle(() => {
    return {
      transform: [
        { translateX: translateX.value - 30 },
        { translateY: translateY.value },
        { scale: scale.value },
        { rotateZ: `${interpolate(rotation.value, [0, 360], [0, hasSpeed ? 720 : 360])}deg` },
      ],
    };
  });

  const getPlayerColor = () => {
    if (hasJetpack) return '#10B981';
    if (hasSpeed) return '#EF4444';
    return '#F59E0B';
  };

  return (
    <Animated.View style={[styles.player, animatedStyle]}>
      <View style={[styles.playerBody, { backgroundColor: getPlayerColor() }]}>
        <View style={styles.playerHead} />
        <View style={styles.playerArms} />
        <View style={styles.playerLegs} />
        
        {hasJetpack && (
          <View style={styles.jetpack}>
            <View style={styles.jetpackFlame} />
          </View>
        )}
        
        {hasSpeed && (
          <View style={styles.speedLines}>
            <View style={[styles.speedLine, { left: -20 }]} />
            <View style={[styles.speedLine, { left: -25 }]} />
            <View style={[styles.speedLine, { left: -30 }]} />
          </View>
        )}
      </View>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  player: {
    position: 'absolute',
    zIndex: 50,
  },
  playerBody: {
    width: 60,
    height: 80,
    borderRadius: 30,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  playerHead: {
    width: 30,
    height: 30,
    borderRadius: 15,
    backgroundColor: '#FED7AA',
    position: 'absolute',
    top: -15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  playerArms: {
    width: 40,
    height: 15,
    borderRadius: 8,
    backgroundColor: '#FED7AA',
    position: 'absolute',
    top: 10,
  },
  playerLegs: {
    width: 30,
    height: 25,
    borderRadius: 15,
    backgroundColor: '#2563EB',
    position: 'absolute',
    bottom: -12,
  },
  jetpack: {
    position: 'absolute',
    top: 5,
    right: -15,
    width: 20,
    height: 40,
    backgroundColor: '#374151',
    borderRadius: 10,
  },
  jetpackFlame: {
    position: 'absolute',
    bottom: -20,
    left: 2,
    width: 16,
    height: 25,
    backgroundColor: '#F59E0B',
    borderRadius: 8,
  },
  speedLines: {
    position: 'absolute',
    top: 0,
    bottom: 0,
    left: 0,
    right: 0,
  },
  speedLine: {
    position: 'absolute',
    top: '50%',
    width: 15,
    height: 2,
    backgroundColor: '#EF4444',
    borderRadius: 1,
    opacity: 0.8,
  },
});