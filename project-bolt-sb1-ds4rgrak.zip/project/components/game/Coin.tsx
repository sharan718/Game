import { View, StyleSheet } from 'react-native';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withTiming,
  withRepeat,
  withSequence,
} from 'react-native-reanimated';
import { useEffect } from 'react';
import { CoinItem } from '@/hooks/useGameLogic';

interface CoinProps {
  coin: CoinItem;
  gameSpeed: number;
}

export function Coin({ coin, gameSpeed }: CoinProps) {
  const translateY = useSharedValue(coin.y);
  const rotation = useSharedValue(0);
  const scale = useSharedValue(1);
  const opacity = useSharedValue(coin.collected ? 0 : 1);

  useEffect(() => {
    translateY.value = coin.y;
  }, [coin.y]);

  useEffect(() => {
    rotation.value = withRepeat(
      withTiming(360, { duration: 2000 }),
      -1,
      false
    );
    
    scale.value = withRepeat(
      withSequence(
        withTiming(1.2, { duration: 1000 }),
        withTiming(1, { duration: 1000 })
      ),
      -1,
      true
    );
  }, []);

  useEffect(() => {
    if (coin.collected) {
      opacity.value = withTiming(0, { duration: 200 });
      scale.value = withTiming(2, { duration: 200 });
    }
  }, [coin.collected]);

  const animatedStyle = useAnimatedStyle(() => {
    return {
      transform: [
        { translateX: coin.x - 15 },
        { translateY: translateY.value },
        { rotateY: `${rotation.value}deg` },
        { scale: scale.value },
      ],
      opacity: opacity.value,
    };
  });

  if (coin.collected) {
    return null;
  }

  return (
    <Animated.View style={[styles.coin, animatedStyle]}>
      <View style={styles.coinInner}>
        <View style={styles.coinCenter} />
      </View>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  coin: {
    position: 'absolute',
    width: 30,
    height: 30,
    zIndex: 20,
  },
  coinInner: {
    width: 30,
    height: 30,
    borderRadius: 15,
    backgroundColor: '#F59E0B',
    borderWidth: 3,
    borderColor: '#D97706',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#F59E0B',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.6,
    shadowRadius: 8,
    elevation: 8,
  },
  coinCenter: {
    width: 15,
    height: 15,
    borderRadius: 8,
    backgroundColor: '#FEF3C7',
    borderWidth: 1,
    borderColor: '#F59E0B',
  },
});