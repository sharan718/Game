import { View, StyleSheet } from 'react-native';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withTiming,
} from 'react-native-reanimated';
import { useEffect } from 'react';
import { Obstacle as ObstacleType } from '@/hooks/useGameLogic';

interface ObstacleProps {
  obstacle: ObstacleType;
  gameSpeed: number;
}

export function Obstacle({ obstacle, gameSpeed }: ObstacleProps) {
  const translateY = useSharedValue(obstacle.y);
  const opacity = useSharedValue(1);

  useEffect(() => {
    translateY.value = obstacle.y;
  }, [obstacle.y]);

  const animatedStyle = useAnimatedStyle(() => {
    return {
      transform: [
        { translateX: obstacle.x - obstacle.width / 2 },
        { translateY: translateY.value },
      ],
      opacity: opacity.value,
    };
  });

  const getObstacleStyle = () => {
    switch (obstacle.type) {
      case 'train':
        return {
          backgroundColor: '#EF4444',
          borderRadius: 8,
          borderWidth: 2,
          borderColor: '#DC2626',
        };
      case 'barrier':
        return {
          backgroundColor: '#F59E0B',
          borderRadius: 4,
          borderWidth: 2,
          borderColor: '#D97706',
        };
      case 'sign':
        return {
          backgroundColor: '#10B981',
          borderRadius: 6,
          borderWidth: 2,
          borderColor: '#059669',
        };
      default:
        return {
          backgroundColor: '#6B7280',
          borderRadius: 4,
        };
    }
  };

  return (
    <Animated.View
      style={[
        styles.obstacle,
        {
          width: obstacle.width,
          height: obstacle.height,
          ...getObstacleStyle(),
        },
        animatedStyle,
      ]}
    >
      {obstacle.type === 'train' && (
        <>
          <View style={styles.trainWindow} />
          <View style={[styles.trainWindow, { top: 20 }]} />
          <View style={styles.trainStripe} />
        </>
      )}
      
      {obstacle.type === 'barrier' && (
        <>
          <View style={styles.barrierStripe} />
          <View style={[styles.barrierStripe, { top: 20 }]} />
          <View style={[styles.barrierStripe, { top: 40 }]} />
        </>
      )}
      
      {obstacle.type === 'sign' && (
        <View style={styles.signText}>
          <View style={styles.signIcon} />
        </View>
      )}
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  obstacle: {
    position: 'absolute',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
    zIndex: 10,
  },
  trainWindow: {
    position: 'absolute',
    top: 10,
    left: 10,
    right: 10,
    height: 15,
    backgroundColor: '#DBEAFE',
    borderRadius: 4,
  },
  trainStripe: {
    position: 'absolute',
    bottom: 10,
    left: 0,
    right: 0,
    height: 4,
    backgroundColor: '#FEF3C7',
  },
  barrierStripe: {
    position: 'absolute',
    top: 10,
    left: 0,
    right: 0,
    height: 8,
    backgroundColor: '#FEF3C7',
    borderRadius: 2,
  },
  signText: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  signIcon: {
    width: 20,
    height: 20,
    backgroundColor: '#FFFFFF',
    borderRadius: 10,
  },
});