import { View, StyleSheet } from 'react-native';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withTiming,
  withRepeat,
  withSequence,
} from 'react-native-reanimated';
import { useEffect } from 'react';
import { PowerUpItem } from '@/hooks/useGameLogic';

interface PowerUpProps {
  powerUp: PowerUpItem;
  gameSpeed: number;
}

export function PowerUp({ powerUp, gameSpeed }: PowerUpProps) {
  const translateY = useSharedValue(powerUp.y);
  const rotation = useSharedValue(0);
  const scale = useSharedValue(1);
  const opacity = useSharedValue(powerUp.collected ? 0 : 1);

  useEffect(() => {
    translateY.value = powerUp.y;
  }, [powerUp.y]);

  useEffect(() => {
    rotation.value = withRepeat(
      withTiming(360, { duration: 3000 }),
      -1,
      false
    );
    
    scale.value = withRepeat(
      withSequence(
        withTiming(1.3, { duration: 1500 }),
        withTiming(1, { duration: 1500 })
      ),
      -1,
      true
    );
  }, []);

  useEffect(() => {
    if (powerUp.collected) {
      opacity.value = withTiming(0, { duration: 300 });
      scale.value = withTiming(2.5, { duration: 300 });
    }
  }, [powerUp.collected]);

  const animatedStyle = useAnimatedStyle(() => {
    return {
      transform: [
        { translateX: powerUp.x - 25 },
        { translateY: translateY.value },
        { rotateZ: `${rotation.value}deg` },
        { scale: scale.value },
      ],
      opacity: opacity.value,
    };
  });

  const getPowerUpStyle = () => {
    switch (powerUp.type) {
      case 'jetpack':
        return {
          backgroundColor: '#10B981',
          borderColor: '#059669',
        };
      case 'magnet':
        return {
          backgroundColor: '#8B5CF6',
          borderColor: '#7C3AED',
        };
      case 'multiplier':
        return {
          backgroundColor: '#F59E0B',
          borderColor: '#D97706',
        };
      case 'speed':
        return {
          backgroundColor: '#EF4444',
          borderColor: '#DC2626',
        };
      default:
        return {
          backgroundColor: '#6B7280',
          borderColor: '#4B5563',
        };
    }
  };

  const getPowerUpIcon = () => {
    switch (powerUp.type) {
      case 'jetpack':
        return <View style={styles.jetpackIcon} />;
      case 'magnet':
        return <View style={styles.magnetIcon} />;
      case 'multiplier':
        return <View style={styles.multiplierIcon} />;
      case 'speed':
        return <View style={styles.speedIcon} />;
      default:
        return <View style={styles.defaultIcon} />;
    }
  };

  if (powerUp.collected) {
    return null;
  }

  return (
    <Animated.View style={[styles.powerUp, getPowerUpStyle(), animatedStyle]}>
      <View style={styles.powerUpInner}>
        {getPowerUpIcon()}
      </View>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  powerUp: {
    position: 'absolute',
    width: 50,
    height: 50,
    borderRadius: 25,
    borderWidth: 3,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.6,
    shadowRadius: 8,
    elevation: 8,
    zIndex: 30,
  },
  powerUpInner: {
    width: 35,
    height: 35,
    borderRadius: 18,
    backgroundColor: '#FFFFFF',
    justifyContent: 'center',
    alignItems: 'center',
  },
  jetpackIcon: {
    width: 20,
    height: 25,
    backgroundColor: '#10B981',
    borderRadius: 4,
  },
  magnetIcon: {
    width: 18,
    height: 22,
    backgroundColor: '#8B5CF6',
    borderRadius: 9,
  },
  multiplierIcon: {
    width: 20,
    height: 20,
    backgroundColor: '#F59E0B',
    borderRadius: 10,
  },
  speedIcon: {
    width: 22,
    height: 18,
    backgroundColor: '#EF4444',
    borderRadius: 4,
  },
  defaultIcon: {
    width: 18,
    height: 18,
    backgroundColor: '#6B7280',
    borderRadius: 9,
  },
});