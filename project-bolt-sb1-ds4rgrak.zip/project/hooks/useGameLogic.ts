import { useState, useEffect, useCallback, useRef } from 'react';
import { useGameStore } from '@/store/gameStore';
import { Dimensions } from 'react-native';

const { width: SCREEN_WIDTH, height: SCREEN_HEIGHT } = Dimensions.get('window');

export type GameState = 'waiting' | 'playing' | 'paused' | 'gameOver';
export type PlayerAction = 'idle' | 'jumping' | 'sliding';
export type PowerUpType = 'jetpack' | 'magnet' | 'multiplier' | 'speed';

export interface Position {
  x: number;
  y: number;
  lane: number;
  action: PlayerAction;
}

export interface GameObject {
  id: string;
  x: number;
  y: number;
  lane: number;
  type: string;
}

export interface Obstacle extends GameObject {
  type: 'train' | 'barrier' | 'sign';
  width: number;
  height: number;
}

export interface CoinItem extends GameObject {
  type: 'coin';
  collected: boolean;
}

export interface PowerUpItem extends GameObject {
  type: PowerUpType;
  collected: boolean;
}

export interface ActivePowerUp {
  type: PowerUpType;
  duration: number;
  maxDuration: number;
}

const LANE_WIDTH = SCREEN_WIDTH / 3;
const LANE_POSITIONS = [
  LANE_WIDTH / 2,
  LANE_WIDTH + LANE_WIDTH / 2,
  LANE_WIDTH * 2 + LANE_WIDTH / 2,
];

const INITIAL_GAME_SPEED = 3;
const MAX_GAME_SPEED = 8;
const SPEED_INCREASE_RATE = 0.001;

export function useGameLogic() {
  const [gameState, setGameState] = useState<GameState>('waiting');
  const [score, setScore] = useState(0);
  const [coins, setCoins] = useState(0);
  const [gameSpeed, setGameSpeed] = useState(INITIAL_GAME_SPEED);
  const [obstacles, setObstacles] = useState<Obstacle[]>([]);
  const [coinItems, setCoinItems] = useState<CoinItem[]>([]);
  const [powerUps, setPowerUps] = useState<PowerUpItem[]>([]);
  const [activePowerUps, setActivePowerUps] = useState<ActivePowerUp[]>([]);
  
  const [playerPosition, setPlayerPosition] = useState<Position>({
    x: LANE_POSITIONS[1],
    y: SCREEN_HEIGHT - 200,
    lane: 1,
    action: 'idle',
  });

  const gameLoopRef = useRef<NodeJS.Timeout | null>(null);
  const obstacleSpawnRef = useRef<NodeJS.Timeout | null>(null);
  const coinSpawnRef = useRef<NodeJS.Timeout | null>(null);
  const powerUpSpawnRef = useRef<NodeJS.Timeout | null>(null);
  const scoreRef = useRef(0);

  const { setHighScore, addCoins, incrementGames } = useGameStore();

  const isGameRunning = gameState === 'playing';

  const generateObstacle = useCallback((): Obstacle => {
    const lane = Math.floor(Math.random() * 3);
    const types: Obstacle['type'][] = ['train', 'barrier', 'sign'];
    const type = types[Math.floor(Math.random() * types.length)];
    
    return {
      id: `obstacle-${Date.now()}-${Math.random()}`,
      x: LANE_POSITIONS[lane],
      y: -100,
      lane,
      type,
      width: 60,
      height: type === 'train' ? 120 : 80,
    };
  }, []);

  const generateCoin = useCallback((): CoinItem => {
    const lane = Math.floor(Math.random() * 3);
    
    return {
      id: `coin-${Date.now()}-${Math.random()}`,
      x: LANE_POSITIONS[lane],
      y: -50,
      lane,
      type: 'coin',
      collected: false,
    };
  }, []);

  const generatePowerUp = useCallback((): PowerUpItem => {
    const lane = Math.floor(Math.random() * 3);
    const types: PowerUpType[] = ['jetpack', 'magnet', 'multiplier', 'speed'];
    const type = types[Math.floor(Math.random() * types.length)];
    
    return {
      id: `powerup-${Date.now()}-${Math.random()}`,
      x: LANE_POSITIONS[lane],
      y: -80,
      lane,
      type,
      collected: false,
    };
  }, []);

  const checkCollision = useCallback((obj1: Position, obj2: GameObject, threshold = 50) => {
    const distance = Math.sqrt(
      Math.pow(obj1.x - obj2.x, 2) + Math.pow(obj1.y - obj2.y, 2)
    );
    return distance < threshold;
  }, []);

  const gameLoop = useCallback(() => {
    if (gameState !== 'playing') return;

    // Update score
    scoreRef.current += 1;
    setScore(scoreRef.current);

    // Increase game speed
    setGameSpeed(prev => Math.min(prev + SPEED_INCREASE_RATE, MAX_GAME_SPEED));

    // Move obstacles
    setObstacles(prev => 
      prev.map(obstacle => ({
        ...obstacle,
        y: obstacle.y + gameSpeed,
      })).filter(obstacle => obstacle.y < SCREEN_HEIGHT + 100)
    );

    // Move coins
    setCoinItems(prev => 
      prev.map(coin => ({
        ...coin,
        y: coin.y + gameSpeed,
      })).filter(coin => coin.y < SCREEN_HEIGHT + 100 && !coin.collected)
    );

    // Move power-ups
    setPowerUps(prev => 
      prev.map(powerUp => ({
        ...powerUp,
        y: powerUp.y + gameSpeed,
      })).filter(powerUp => powerUp.y < SCREEN_HEIGHT + 100 && !powerUp.collected)
    );

    // Update active power-ups
    setActivePowerUps(prev => 
      prev.map(powerUp => ({
        ...powerUp,
        duration: powerUp.duration - 1,
      })).filter(powerUp => powerUp.duration > 0)
    );

    // Check collisions
    const currentPlayerPos = playerPosition;
    
    // Obstacle collisions
    obstacles.forEach(obstacle => {
      if (checkCollision(currentPlayerPos, obstacle)) {
        if (currentPlayerPos.action !== 'sliding' || obstacle.type !== 'barrier') {
          gameOver();
        }
      }
    });

    // Coin collisions
    coinItems.forEach(coin => {
      if (!coin.collected && checkCollision(currentPlayerPos, coin, 40)) {
        setCoinItems(prev => 
          prev.map(c => c.id === coin.id ? { ...c, collected: true } : c)
        );
        setCoins(prev => prev + 1);
      }
    });

    // Power-up collisions
    powerUps.forEach(powerUp => {
      if (!powerUp.collected && checkCollision(currentPlayerPos, powerUp, 40)) {
        setPowerUps(prev => 
          prev.map(p => p.id === powerUp.id ? { ...p, collected: true } : p)
        );
        
        const duration = powerUp.type === 'jetpack' ? 300 : 180;
        setActivePowerUps(prev => [...prev, {
          type: powerUp.type,
          duration,
          maxDuration: duration,
        }]);
      }
    });

  }, [gameState, gameSpeed, obstacles, coinItems, powerUps, playerPosition, checkCollision]);

  const startGame = useCallback(() => {
    setGameState('playing');
    setScore(0);
    setCoins(0);
    scoreRef.current = 0;
    setGameSpeed(INITIAL_GAME_SPEED);
    setObstacles([]);
    setCoinItems([]);
    setPowerUps([]);
    setActivePowerUps([]);
    setPlayerPosition({
      x: LANE_POSITIONS[1],
      y: SCREEN_HEIGHT - 200,
      lane: 1,
      action: 'idle',
    });
    incrementGames();
  }, [incrementGames]);

  const pauseGame = useCallback(() => {
    setGameState('paused');
  }, []);

  const gameOver = useCallback(() => {
    setGameState('gameOver');
    setHighScore(scoreRef.current);
    addCoins(coins);
    
    // Clear intervals
    if (gameLoopRef.current) clearInterval(gameLoopRef.current);
    if (obstacleSpawnRef.current) clearInterval(obstacleSpawnRef.current);
    if (coinSpawnRef.current) clearInterval(coinSpawnRef.current);
    if (powerUpSpawnRef.current) clearInterval(powerUpSpawnRef.current);
  }, [coins, setHighScore, addCoins]);

  const movePlayer = useCallback((direction: 'left' | 'right') => {
    setPlayerPosition(prev => {
      const newLane = direction === 'left' 
        ? Math.max(0, prev.lane - 1)
        : Math.min(2, prev.lane + 1);
      
      return {
        ...prev,
        lane: newLane,
        x: LANE_POSITIONS[newLane],
      };
    });
  }, []);

  const jumpPlayer = useCallback(() => {
    setPlayerPosition(prev => ({ ...prev, action: 'jumping' }));
    setTimeout(() => {
      setPlayerPosition(prev => ({ ...prev, action: 'idle' }));
    }, 500);
  }, []);

  const slidePlayer = useCallback(() => {
    setPlayerPosition(prev => ({ ...prev, action: 'sliding' }));
    setTimeout(() => {
      setPlayerPosition(prev => ({ ...prev, action: 'idle' }));
    }, 500);
  }, []);

  // Game loop effect
  useEffect(() => {
    if (gameState === 'playing') {
      gameLoopRef.current = setInterval(gameLoop, 16); // 60 FPS
      
      // Spawn obstacles
      obstacleSpawnRef.current = setInterval(() => {
        if (Math.random() < 0.7) {
          setObstacles(prev => [...prev, generateObstacle()]);
        }
      }, 2000);

      // Spawn coins
      coinSpawnRef.current = setInterval(() => {
        if (Math.random() < 0.8) {
          setCoinItems(prev => [...prev, generateCoin()]);
        }
      }, 1500);

      // Spawn power-ups
      powerUpSpawnRef.current = setInterval(() => {
        if (Math.random() < 0.3) {
          setPowerUps(prev => [...prev, generatePowerUp()]);
        }
      }, 5000);
    }

    return () => {
      if (gameLoopRef.current) clearInterval(gameLoopRef.current);
      if (obstacleSpawnRef.current) clearInterval(obstacleSpawnRef.current);
      if (coinSpawnRef.current) clearInterval(coinSpawnRef.current);
      if (powerUpSpawnRef.current) clearInterval(powerUpSpawnRef.current);
    };
  }, [gameState, gameLoop, generateObstacle, generateCoin, generatePowerUp]);

  return {
    gameState,
    playerPosition,
    score,
    coins,
    isGameRunning,
    obstacles,
    coinItems,
    powerUps,
    activePowerUps,
    gameSpeed,
    startGame,
    pauseGame,
    gameOver,
    movePlayer,
    jumpPlayer,
    slidePlayer,
  };
}