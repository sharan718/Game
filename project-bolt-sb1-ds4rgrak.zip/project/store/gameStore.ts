import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';

interface GameState {
  highScore: number;
  coins: number;
  totalGames: number;
  ownedItems: string[];
  currentCharacter: string;
  setHighScore: (score: number) => void;
  addCoins: (amount: number) => void;
  spendCoins: (amount: number) => void;
  incrementGames: () => void;
  purchaseItem: (itemId: string, cost: number) => void;
  setCurrentCharacter: (characterId: string) => void;
  resetProgress: () => void;
}

export const useGameStore = create<GameState>()(
  persist(
    (set, get) => ({
      highScore: 0,
      coins: 0,
      totalGames: 0,
      ownedItems: ['character_jake'],
      currentCharacter: 'character_jake',
      
      setHighScore: (score: number) =>
        set((state) => ({
          highScore: Math.max(state.highScore, score),
        })),
      
      addCoins: (amount: number) =>
        set((state) => ({
          coins: state.coins + amount,
        })),
      
      spendCoins: (amount: number) =>
        set((state) => ({
          coins: Math.max(0, state.coins - amount),
        })),
      
      incrementGames: () =>
        set((state) => ({
          totalGames: state.totalGames + 1,
        })),
      
      purchaseItem: (itemId: string, cost: number) =>
        set((state) => {
          if (state.coins >= cost && !state.ownedItems.includes(itemId)) {
            return {
              coins: state.coins - cost,
              ownedItems: [...state.ownedItems, itemId],
            };
          }
          return state;
        }),
      
      setCurrentCharacter: (characterId: string) =>
        set((state) => {
          if (state.ownedItems.includes(characterId)) {
            return { currentCharacter: characterId };
          }
          return state;
        }),
      
      resetProgress: () =>
        set({
          highScore: 0,
          coins: 0,
          totalGames: 0,
          ownedItems: ['character_jake'],
          currentCharacter: 'character_jake',
        }),
    }),
    {
      name: 'subway-surfers-game',
      storage: createJSONStorage(() => localStorage),
    }
  )
);